package com.foodapp.order.controller;

import com.foodapp.order.dto.CartItemDTO;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/cart")
public class CartController {
    private Map<String, CartItemDTO> cart = new HashMap<>();

    @PostMapping("/items")
    public String addItem(@RequestBody CartItemDTO dto) {
        cart.put(dto.getMenuItemId(), dto);
        return "Item added";
    }

    @GetMapping
    public Collection<CartItemDTO> viewCart() {
        return cart.values();
    }

    @DeleteMapping("/items/{id}")
    public String removeItem(@PathVariable String id) {
        cart.remove(id);
        return "Item removed";
    }
}
