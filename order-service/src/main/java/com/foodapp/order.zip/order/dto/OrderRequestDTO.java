package com.foodapp.order.dto;

import com.foodapp.order.entity.OrderItem;
import lombok.Data;
import java.util.List;

@Data
public class OrderRequestDTO {
    private String userId;
    private String vendorId;
    private List<OrderItem> items;
    private double total;
}
