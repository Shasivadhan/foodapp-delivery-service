package com.foodapp.order.controller;

import com.foodapp.order.dto.OrderRequestDTO;
import com.foodapp.order.entity.Order;
import com.foodapp.order.repository.OrderRepository;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/orders")
public class OrderController {
    private final OrderRepository orderRepository;
    public OrderController(OrderRepository orderRepository) { this.orderRepository = orderRepository; }

    @PostMapping
    public Order placeOrder(@RequestBody OrderRequestDTO dto) {
        Order order = new Order();
        order.setUserId(dto.getUserId());
        order.setVendorId(dto.getVendorId());
        order.setItems(dto.getItems());
        order.setTotal(dto.getTotal());
        order.setStatus("PAID"); // integrate Bank Service later
        order.setCreatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @GetMapping
    public Iterable<Order> getOrders() {
        return orderRepository.findAll();
    }
}
