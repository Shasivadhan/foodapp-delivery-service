package com.foodapp.order.kafka;

import java.math.BigDecimal;
import java.util.List;

public class DeliveryEvent {
    private String orderId;
    private String userId;
    private List<String> productNames;
    private BigDecimal totalAmount;
    private String deliveryDate;
}
